sap.ui.define([
	"synce21/ex4/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
