/* global QUnit */

sap.ui.require(["sync/e21/ex4/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
