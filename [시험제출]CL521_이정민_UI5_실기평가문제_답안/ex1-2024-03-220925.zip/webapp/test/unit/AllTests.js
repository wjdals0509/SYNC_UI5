sap.ui.define([
	"synce21/ex1/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
