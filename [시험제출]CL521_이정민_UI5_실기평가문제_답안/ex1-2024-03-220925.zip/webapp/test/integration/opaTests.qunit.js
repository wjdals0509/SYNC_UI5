/* global QUnit */

sap.ui.require(["sync/e21/ex1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
