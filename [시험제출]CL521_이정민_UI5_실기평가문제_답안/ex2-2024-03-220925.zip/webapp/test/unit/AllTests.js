sap.ui.define([
	"synce21/ex2/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
