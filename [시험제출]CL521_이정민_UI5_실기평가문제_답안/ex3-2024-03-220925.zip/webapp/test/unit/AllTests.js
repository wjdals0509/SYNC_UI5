sap.ui.define([
	"synce21/ex3/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
